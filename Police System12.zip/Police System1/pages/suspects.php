<?php
require_once __DIR__ . '/../config/config.php';
require_login();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Suspects - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/css/styles.css">
</head>
<body>
    <div class="topbar">
        <div class="brand"><?php echo APP_NAME; ?></div>
        <?php $pg = basename(__FILE__); ?>
        <nav>
            <a class="<?php echo $pg==='dashboard.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/dashboard.php"><i class="bi bi-speedometer2"></i>Dashboard</a>
            <a class="<?php echo $pg==='suspects.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/suspects.php"><i class="bi bi-people"></i>Suspects</a>
            <a class="<?php echo $pg==='cases.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/cases.php"><i class="bi bi-folder2"></i>Cases</a>
            <a class="<?php echo $pg==='assign_suspects.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/assign_suspects.php"><i class="bi bi-link-45deg"></i>Assign</a>
            <a class="<?php echo $pg==='reports.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/reports.php"><i class="bi bi-file-earmark-text"></i>Reports</a>
            <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
            <a class="<?php echo $pg==='users.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/users.php"><i class="bi bi-people-gear"></i>Users</a>
            <?php } ?>
        </nav>
        <div class="right">
            <?php $nm = $_SESSION['name'] ?? 'User'; $rl = $_SESSION['role'] ?? ''; ?>
            <span>Welcome, <?php echo htmlspecialchars($nm); ?><?php echo $rl !== '' ? ' ('.htmlspecialchars($rl).')' : ''; ?></span>
            <button class="btn secondary" id="logoutBtn">Logout</button>
        </div>
    </div>
    <div class="container">
        <div id="successMsg" class="alert alert-success" style="display:none; margin-bottom:8px;"></div>
        <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
            <input id="search" class="form-control" placeholder="Search by name, ID, phone" style="flex:1; max-width:360px;" />
            <button class="btn btn-primary" id="addBtn">Add Suspect</button>
        </div>

        <div style="margin-top:12px; overflow-x:auto;">
            <table class="table table-striped table-hover table-compact" id="suspectsTable">
                <thead>
                    <tr>
                        <th class="sticky">ID</th>
                        <th class="sticky">Name</th>
                        <th class="sticky nowrap">National ID</th>
                        <th class="sticky nowrap">Phone</th>
                        <th class="sticky">Address</th>
                        <th class="sticky nowrap">DOB</th>
                        <th class="sticky nowrap">Gender</th>
                        <?php if (!empty($_SESSION['role']) && $_SESSION['role'] !== 'investigator') { ?>
                        <th>Actions</th>
                        <?php } ?>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

    <dialog id="suspectDialog">
        <form method="dialog" id="suspectForm" class="p-2" style="min-width:360px;">
            <h3 id="dlgTitle" class="mb-2">Add Suspect</h3>
            <input type="hidden" id="suspectId" />
            <div class="mb-2">
                <label class="form-label">Full Name</label>
                <input id="full_name" class="form-control" placeholder="e.g. Ahmed Ali" required />
            </div>
            <div class="row g-2">
                <div class="col-md-6">
                    <label class="form-label">National ID</label>
                    <input id="national_id" class="form-control" placeholder="Optional" />
                </div>
                <div class="col-md-6">
                    <label class="form-label">Phone</label>
                    <input id="phone" class="form-control" placeholder="Optional" />
                </div>
            </div>
            <div class="mb-2">
                <label class="form-label">Address</label>
                <input id="address" class="form-control" placeholder="Street, City" />
            </div>
            <div class="row g-2">
                <div class="col-md-6">
                    <label class="form-label">Date of Birth</label>
                    <input id="date_of_birth" type="date" class="form-control" />
                </div>
                <div class="col-md-6">
                    <label class="form-label">Gender</label>
                    <select id="gender" class="form-select">
                        <option value="">-</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>
            </div>
            <div class="d-flex gap-2 mt-3">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="button" id="cancelDlg" class="btn btn-secondary">Cancel</button>
            </div>
            <div id="formError" class="error" style="display:none; margin-top:8px;"></div>
        </form>
    </dialog>

    <script>
    const base = '<?php echo BASE_URL; ?>';
    const CAN_MANAGE = <?php echo (!empty($_SESSION['role']) && in_array($_SESSION['role'], ['admin','officer'], true)) ? 'true' : 'false'; ?>;
    const IS_INVESTIGATOR = <?php echo (!empty($_SESSION['role']) && $_SESSION['role'] === 'investigator') ? 'true' : 'false'; ?>;

    document.getElementById('logoutBtn').addEventListener('click', async () => {
        const res = await fetch(`${base}/api/auth/logout.php`, { method: 'POST' });
        if (res.ok) window.location.href = `${base}/pages/login.php`;
    });

    const tbody = document.querySelector('#suspectsTable tbody');
    const search = document.getElementById('search');
    const successMsg = document.getElementById('successMsg');
    function showSuccess(message){
        if(!successMsg) return;
        successMsg.textContent = message;
        successMsg.style.display = 'block';
        setTimeout(()=>{ successMsg.style.display = 'none'; }, 3000);
    }
    async function loadSuspects() {
        const q = search.value.trim();
        const res = await fetch(`${base}/api/suspects/list.php${q ? `?q=${encodeURIComponent(q)}` : ''}`);
        const data = await res.json();
        tbody.innerHTML = '';
        for (const s of data.data) {
            const tr = document.createElement('tr');
            const actions = CAN_MANAGE ? `<button class="btn secondary" data-edit="${s.id}">Edit</button> <button class=\"btn danger\" data-del="${s.id}">Delete</button>` : '';
            const cols = [
                `<td>${s.id}</td>`,
                `<td class=\"truncate\" title=\"${s.full_name ?? ''}\">${s.full_name ?? ''}</td>`,
                `<td class=\"nowrap\">${s.national_id ?? ''}</td>`,
                `<td class=\"nowrap\">${s.phone ?? ''}</td>`,
                `<td class=\"truncate\" title=\"${s.address ?? ''}\">${s.address ?? ''}</td>`,
                `<td class=\"nowrap\">${s.date_of_birth ?? ''}</td>`,
                `<td class=\"nowrap\">${s.gender ?? ''}</td>`
            ];
            if (!IS_INVESTIGATOR) cols.push(`<td class=\"actions\">${actions}</td>`);
            tr.innerHTML = cols.join('');
            tbody.appendChild(tr);
        }
    }

    search.addEventListener('input', () => { loadSuspects(); });

    const dlg = document.getElementById('suspectDialog');
    const form = document.getElementById('suspectForm');
    const errorBox = document.getElementById('formError');
    document.getElementById('addBtn').addEventListener('click', () => {
        form.reset();
        document.getElementById('suspectId').value = '';
        document.getElementById('dlgTitle').textContent = 'Add Suspect';
        errorBox.style.display = 'none';
        dlg.showModal();
    });
    document.getElementById('cancelDlg').addEventListener('click', () => dlg.close());

    tbody.addEventListener('click', async (e) => {
        const editId = e.target.getAttribute('data-edit');
        const delId = e.target.getAttribute('data-del');
        if (editId) {
            const tr = e.target.closest('tr');
            document.getElementById('suspectId').value = editId;
            document.getElementById('full_name').value = tr.children[1].textContent;
            document.getElementById('national_id').value = tr.children[2].textContent;
            document.getElementById('phone').value = tr.children[3].textContent;
            document.getElementById('address').value = tr.children[4].textContent;
            document.getElementById('date_of_birth').value = tr.children[5].textContent;
            document.getElementById('gender').value = tr.children[6].textContent;
            document.getElementById('dlgTitle').textContent = 'Edit Suspect';
            errorBox.style.display = 'none';
            dlg.showModal();
        }
        if (delId) {
            if (!confirm('Delete this suspect?')) return;
            const res = await fetch(`${base}/api/suspects/delete.php?id=${delId}`, { method: 'POST' });
            if (res.ok) { showSuccess('Suspect deleted successfully'); loadSuspects(); }
        }
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        errorBox.style.display = 'none';
        const payload = {
            full_name: document.getElementById('full_name').value.trim(),
            national_id: document.getElementById('national_id').value.trim(),
            phone: document.getElementById('phone').value.trim(),
            address: document.getElementById('address').value.trim(),
            date_of_birth: document.getElementById('date_of_birth').value,
            gender: document.getElementById('gender').value,
        };
        const id = document.getElementById('suspectId').value;
        let url = `${base}/api/suspects/create.php`;
        let method = 'POST';
        if (id) {
            url = `${base}/api/suspects/update.php`;
            payload.id = id;
            method = 'POST';
        }
        try {
            const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Request failed');
            dlg.close();
            const isUpdate = !!document.getElementById('suspectId').value;
            showSuccess(isUpdate ? 'Suspect updated successfully' : 'Suspect added successfully');
            await loadSuspects();
        } catch (err) {
            errorBox.textContent = err.message;
            errorBox.style.display = 'block';
        }
    });

    loadSuspects();
    </script>
</body>
</html>


