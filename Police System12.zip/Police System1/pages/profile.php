<?php
require_once __DIR__ . '/../config/config.php';
require_login();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Profile - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/css/styles.css">
</head>
<body>
    <div class="topbar">
        <div class="brand"><?php echo APP_NAME; ?></div>
        <?php $pg = basename(__FILE__); ?>
        <nav>
            <a class="<?php echo $pg==='dashboard.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/dashboard.php"><i class="bi bi-speedometer2"></i>Dashboard</a>
            <a class="<?php echo $pg==='suspects.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/suspects.php"><i class="bi bi-people"></i>Suspects</a>
            <a class="<?php echo $pg==='cases.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/cases.php"><i class="bi bi-folder2"></i>Cases</a>
            <a class="<?php echo $pg==='assign_suspects.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/assign_suspects.php"><i class="bi bi-link-45deg"></i>Assign</a>
            <a class="<?php echo $pg==='reports.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/reports.php"><i class="bi bi-file-earmark-text"></i>Reports</a>
            <a class="<?php echo $pg==='profile.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/profile.php"><i class="bi bi-person-circle"></i>Profile</a>
            <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
            <a class="<?php echo $pg==='users.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/users.php"><i class="bi bi-people-gear"></i>Users</a>
            <?php } ?>
        </nav>
        <div class="right">
            <?php $nm = $_SESSION['name'] ?? 'User'; $rl = $_SESSION['role'] ?? ''; ?>
            <span>Welcome, <?php echo htmlspecialchars($nm); ?><?php echo $rl !== '' ? ' ('.htmlspecialchars($rl).')' : ''; ?></span>
            <button class="btn secondary" id="logoutBtn">Logout</button>
        </div>
    </div>
    <div class="container">
        <div class="row g-3">
            <div class="col-md-5">
                <div class="stat">
                    <h4>Personal Info</h4>
                    <?php $em = $_SESSION['email'] ?? ''; ?>
                    <div class="mb-2"><label class="form-label">User Name</label>
                        <div class="input-group">
                            <input id="pi_name" class="form-control" value="<?php echo htmlspecialchars($nm); ?>" />
                            <button id="pi_save" class="btn btn-primary">Save</button>
                        </div>
                        <div id="pi_msg" class="error" style="display:none; margin-top:8px;"></div>
                    </div>
                    <div class="mb-2"><strong>Email:</strong> <?php echo htmlspecialchars($em); ?></div>
                    <div class="mb-2"><strong>Role:</strong> <?php echo htmlspecialchars($rl); ?></div>
                </div>
                <div class="stat" style="margin-top:12px;">
                    <h4>Profile Image</h4>
                    <div class="mb-2">
                        <?php
                        $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
                        $img = null;
                        try {
                            $stmt = $pdo->prepare('SELECT profile_image FROM users WHERE id=?');
                            $stmt->execute([$_SESSION['user_id']]);
                            $img = $stmt->fetchColumn();
                        } catch (PDOException $e) {
                            if ($e->getCode() !== '42S22') { throw $e; }
                            // Column does not exist yet; ignore and show placeholder
                        }
                        ?>
                        <div style="display:flex; align-items:center; gap:12px;">
                            <img id="profilePreview" src="<?php echo $img ? htmlspecialchars(BASE_URL . $img) : 'https://via.placeholder.com/80'; ?>" alt="profile" style="width:80px; height:80px; border-radius:50%; object-fit:cover; background:#f3f4f6;" />
                            <input type="file" id="profileFile" accept="image/*" class="form-control" style="max-width:260px;" />
                        </div>
                        <button id="uploadBtn" class="btn btn-secondary" style="margin-top:8px;">Upload</button>
                        <div id="up_msg" class="error" style="display:none; margin-top:8px;"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-7">
                <div class="stat">
                    <h4>Change Password</h4>
                    <p style="color:#6b7280; font-size:14px;">This is a placeholder. Implement password change endpoint to enable.</p>
                    <div class="row g-2">
                        <div class="col-md-6"><input id="new_password" type="password" class="form-control" placeholder="New password" /></div>
                        <div class="col-md-6"><input id="confirm_password" type="password" class="form-control" placeholder="Confirm password" /></div>
                        <div class="col-12"><button class="btn btn-secondary w-100" id="changeBtn" disabled>Change Password</button></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    document.getElementById('logoutBtn').addEventListener('click', async () => {
        const res = await fetch('<?php echo BASE_URL; ?>/api/auth/logout.php', { method: 'POST' });
        if (res.ok) window.location.href = '<?php echo BASE_URL; ?>/pages/login.php';
    });

    document.getElementById('pi_save').addEventListener('click', async () => {
        const name = document.getElementById('pi_name').value.trim();
        const msg = document.getElementById('pi_msg');
        msg.style.display = 'none';
        try{
            const res = await fetch('<?php echo BASE_URL; ?>/api/auth/update_me.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ name }) });
            const data = await res.json();
            if(!res.ok) throw new Error(data.error||'Update failed');
            msg.textContent = 'Saved';
            msg.style.background = '#dcfce7';
            msg.style.color = '#065f46';
            msg.style.display = 'block';
        }catch(e){ msg.textContent = e.message; msg.style.display = 'block'; }
    });

    document.getElementById('uploadBtn').addEventListener('click', async () => {
        const file = document.getElementById('profileFile').files[0];
        const msg = document.getElementById('up_msg');
        msg.style.display = 'none';
        if(!file){ msg.textContent='Select an image first'; msg.style.display='block'; return; }
        const fd = new FormData();
        fd.append('image', file);
        try{
            const res = await fetch('<?php echo BASE_URL; ?>/api/auth/upload_profile_image.php', { method:'POST', body: fd });
            const data = await res.json();
            if(!res.ok) throw new Error(data.error||'Upload failed');
            document.getElementById('profilePreview').src = '<?php echo BASE_URL; ?>' + data.path;
        }catch(e){ msg.textContent = e.message; msg.style.display = 'block'; }
    });
    </script>
</body>
</html>
