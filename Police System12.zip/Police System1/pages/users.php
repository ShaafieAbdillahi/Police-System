<?php
require_once __DIR__ . '/../config/config.php';
require_login();
require_role(['admin']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Users - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/css/styles.css">
</head>
<body>
    <div class="topbar">
        <div class="brand"><?php echo APP_NAME; ?></div>
        <nav>
            <a href="<?php echo BASE_URL; ?>/pages/dashboard.php">Dashboard</a>
            <a href="<?php echo BASE_URL; ?>/pages/suspects.php">Suspects</a>
            <a href="<?php echo BASE_URL; ?>/pages/cases.php">Cases</a>
            <a href="<?php echo BASE_URL; ?>/pages/assign_suspects.php">Assign</a>
            <a href="<?php echo BASE_URL; ?>/pages/reports.php">Reports</a>
            <a href="<?php echo BASE_URL; ?>/pages/users.php">Users</a>
        </nav>
        <div class="right">
            <?php $nm = $_SESSION['name'] ?? 'User'; $rl = $_SESSION['role'] ?? ''; ?>
            <span>Welcome, <?php echo htmlspecialchars($nm); ?><?php echo $rl !== '' ? ' ('.htmlspecialchars($rl).')' : ''; ?></span>
            <button class="btn secondary" id="logoutBtn">Logout</button>
        </div>
    </div>
    <div class="container">
        <h2>Users</h2>
        <form id="userForm" class="row g-2" style="max-width:800px;">
            <div class="col-md-4">
                <label class="form-label">Name</label>
                <input id="name" class="form-control" required />
            </div>
            <div class="col-md-4">
                <label class="form-label">Username</label>
                <input id="username" class="form-control" required />
            </div>
            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input id="email" type="email" class="form-control" required />
            </div>
            <div class="col-md-4">
                <label class="form-label">Password</label>
                <input id="password" type="password" class="form-control" required />
            </div>
            <div class="col-md-4">
                <label class="form-label">Role</label>
                <select id="role" class="form-select">
                    <option value="officer">Officer</option>
                    <option value="investigator">Investigator</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <div class="col-12">
                <button class="btn btn-primary" type="submit">Add User</button>
            </div>
            <div class="col-12"><div id="formError" class="error" style="display:none;"></div></div>
        </form>

        <div class="table-responsive" style="margin-top:16px;">
            <table class="table table-striped table-hover table-compact" id="usersTable">
                <thead>
                    <tr>
                        <th class="sticky">ID</th>
                        <th class="sticky">Name</th>
                        <th class="sticky">Username</th>
                        <th class="sticky">Email</th>
                        <th class="sticky">Role</th>
                        <th class="sticky">Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

    <dialog id="editDialog">
        <form method="dialog" id="editForm" class="p-2" style="min-width:420px;">
            <h3 class="mb-2">Edit User</h3>
            <input type="hidden" id="e_id" />
            <div class="mb-2"><label class="form-label">Name</label><input id="e_name" class="form-control" required /></div>
            <div class="mb-2"><label class="form-label">Username</label><input id="e_username" class="form-control" required /></div>
            <div class="mb-2"><label class="form-label">Email</label><input id="e_email" type="email" class="form-control" required /></div>
            <div class="mb-2"><label class="form-label">Role</label>
                <select id="e_role" class="form-select">
                    <option value="officer">Officer</option>
                    <option value="investigator">Investigator</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <div class="mb-2"><label class="form-label">New Password (optional)</label><input id="e_password" type="password" class="form-control" /></div>
            <div class="d-flex gap-2 mt-2"><button class="btn btn-primary" type="submit">Save</button><button class="btn btn-secondary" type="button" id="e_cancel">Cancel</button></div>
            <div id="e_error" class="error" style="display:none; margin-top:8px;"></div>
        </form>
    </dialog>

    <script>
    const base = '<?php echo BASE_URL; ?>';
    document.getElementById('logoutBtn').addEventListener('click', async () => {
        const res = await fetch(`${base}/api/auth/logout.php`, { method: 'POST' });
        if (res.ok) window.location.href = `${base}/pages/login.php`;
    });

    async function loadUsers() {
        const res = await fetch(`${base}/api/users/list.php`);
        const data = await res.json();
        const tbody = document.querySelector('#usersTable tbody');
        tbody.innerHTML = '';
        for (const u of data.data) {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${u.id}</td><td>${u.name}</td><td>${u.username ?? ''}</td><td>${u.email}</td><td>${u.role}</td><td>${u.created_at}</td>
                <td class="actions"><button class="btn secondary" data-edit="${u.id}">Edit</button>
                <button class="btn danger" data-del="${u.id}">Delete</button></td>`;
            tbody.appendChild(tr);
        }
    }

    document.getElementById('userForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const payload = {
            name: document.getElementById('name').value.trim(),
            username: document.getElementById('username').value.trim(),
            email: document.getElementById('email').value.trim(),
            password: document.getElementById('password').value,
            role: document.getElementById('role').value,
        };
        const err = document.getElementById('formError');
        err.style.display = 'none';
        try {
            const res = await fetch(`${base}/api/users/create.php`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Request failed');
            (e.target).reset();
            loadUsers();
        } catch (ex) {
            err.textContent = ex.message;
            err.style.display = 'block';
        }
    });

    const editDlg = document.getElementById('editDialog');
    const editForm = document.getElementById('editForm');
    document.getElementById('e_cancel').addEventListener('click', () => editDlg.close());

    document.querySelector('#usersTable').addEventListener('click', async (e) => {
        const id = e.target.getAttribute('data-edit');
        const delId = e.target.getAttribute('data-del');
        if (id) {
            const tr = e.target.closest('tr');
            document.getElementById('e_id').value = id;
            document.getElementById('e_name').value = tr.children[1].textContent;
            document.getElementById('e_username').value = tr.children[2].textContent;
            document.getElementById('e_email').value = tr.children[3].textContent;
            document.getElementById('e_role').value = tr.children[4].textContent;
            document.getElementById('e_password').value = '';
            document.getElementById('e_error').style.display = 'none';
            editDlg.showModal();
        }
        if (delId) {
            if (!confirm('Delete this user?')) return;
            const res = await fetch(`${base}/api/users/delete.php?id=${delId}`, { method: 'POST' });
            const data = await res.json();
            if (!res.ok) { alert(data.error || 'Delete failed'); return; }
            loadUsers();
        }
    });

    editForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const payload = {
            id: document.getElementById('e_id').value,
            name: document.getElementById('e_name').value.trim(),
            username: document.getElementById('e_username').value.trim(),
            email: document.getElementById('e_email').value.trim(),
            role: document.getElementById('e_role').value,
            password: document.getElementById('e_password').value,
        };
        const err = document.getElementById('e_error');
        err.style.display = 'none';
        const res = await fetch(`${base}/api/users/update.php`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        const data = await res.json();
        if (!res.ok) { err.textContent = data.error || 'Update failed'; err.style.display = 'block'; return; }
        editDlg.close();
        loadUsers();
    });

    loadUsers();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


