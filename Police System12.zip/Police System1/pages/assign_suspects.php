<?php
require_once __DIR__ . '/../config/config.php';
require_login();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Assign Suspects - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/css/styles.css">
</head>
<body>
    <div class="topbar">
        <div class="brand"><?php echo APP_NAME; ?></div>
        <?php $pg = basename(__FILE__); ?>
        <nav>
            <a class="<?php echo $pg==='dashboard.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/dashboard.php"><i class="bi bi-speedometer2"></i>Dashboard</a>
            <a class="<?php echo $pg==='suspects.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/suspects.php"><i class="bi bi-people"></i>Suspects</a>
            <a class="<?php echo $pg==='cases.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/cases.php"><i class="bi bi-folder2"></i>Cases</a>
            <a class="<?php echo $pg==='assign_suspects.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/assign_suspects.php"><i class="bi bi-link-45deg"></i>Assign</a>
            <a class="<?php echo $pg==='reports.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/reports.php"><i class="bi bi-file-earmark-text"></i>Reports</a>
            <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
            <a class="<?php echo $pg==='users.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/users.php"><i class="bi bi-people-gear"></i>Users</a>
            <?php } ?>
        </nav>
        <div class="right">
            <?php $nm = $_SESSION['name'] ?? 'User'; $rl = $_SESSION['role'] ?? ''; ?>
            <span>Welcome, <?php echo htmlspecialchars($nm); ?><?php echo $rl !== '' ? ' ('.htmlspecialchars($rl).')' : ''; ?></span>
            <button class="btn secondary" id="logoutBtn">Logout</button>
        </div>
    </div>
    <div class="container">
        <div class="row g-2">
            <div class="col-md-4">
                <label class="form-label">Case</label>
                <select id="caseSelect" class="form-select"></select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Suspect</label>
                <select id="suspectSelect" class="form-select"></select>
            </div>
            <div class="col-md-4 d-flex align-items-end">
                <button id="assignBtn" class="btn btn-primary">Assign Suspect</button>
            </div>
        </div>

        <div class="table-responsive" style="margin-top:12px;">
            <table class="table table-striped" id="assignedTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Suspect</th>
                        <th>National ID</th>
                        <th>Assigned At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

    <script>
    const base = '<?php echo BASE_URL; ?>';
    const ROLE = '<?php echo $_SESSION['role'] ?? ''; ?>';
    const CAN_ASSIGN = (ROLE === 'investigator' || ROLE === 'admin' || ROLE === 'officer');
    document.getElementById('logoutBtn').addEventListener('click', async () => {
        const res = await fetch(`${base}/api/auth/logout.php`, { method: 'POST' });
        if (res.ok) window.location.href = `${base}/pages/login.php`;
    });

    async function loadCases() {
        const res = await fetch(`${base}/api/cases/list.php`);
        const data = await res.json();
        const sel = document.getElementById('caseSelect');
        sel.innerHTML = '';
        for (const c of data.data) {
            const opt = document.createElement('option');
            opt.value = c.id;
            opt.textContent = `${c.case_number} - ${c.title}`;
            sel.appendChild(opt);
        }
    }
    async function loadSuspectsOptions() {
        const res = await fetch(`${base}/api/suspects/list.php`);
        const data = await res.json();
        const sel = document.getElementById('suspectSelect');
        sel.innerHTML = '';
        for (const s of data.data) {
            const opt = document.createElement('option');
            opt.value = s.id;
            opt.textContent = `${s.full_name}${s.national_id ? ' (' + s.national_id + ')' : ''}`;
            sel.appendChild(opt);
        }
    }
    async function loadAssigned() {
        const caseId = document.getElementById('caseSelect').value;
        if (!caseId) return;
        const res = await fetch(`${base}/api/assign/list_by_case.php?case_id=${caseId}`);
        const data = await res.json();
        const tbody = document.querySelector('#assignedTable tbody');
        tbody.innerHTML = '';
        for (const a of data.data) {
            const tr = document.createElement('tr');
            const actions = CAN_ASSIGN ? `<button class=\"btn btn-danger btn-sm\" data-unassign=\"${a.id}\">Remove</button>` : '';
            tr.innerHTML = `
                <td>${a.id}</td>
                <td>${a.full_name}</td>
                <td>${a.national_id ?? ''}</td>
                <td>${a.created_at}</td>
                <td>${actions}</td>
            `;
            tbody.appendChild(tr);
        }
    }

    document.getElementById('caseSelect').addEventListener('change', loadAssigned);
    if (!CAN_ASSIGN) {
        document.getElementById('assignBtn').style.display = 'none';
    }
    document.getElementById('assignBtn').addEventListener('click', async () => {
        const case_id = parseInt(document.getElementById('caseSelect').value, 10);
        const suspect_id = parseInt(document.getElementById('suspectSelect').value, 10);
        if (!case_id || !suspect_id) return;
        const res = await fetch(`${base}/api/assign/assign.php`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ case_id, suspect_id }) });
        if (res.ok) loadAssigned();
    });

    document.querySelector('#assignedTable tbody').addEventListener('click', async (e) => {
        const id = e.target.getAttribute('data-unassign');
        if (!id) return;
        if (!confirm('Remove this assignment?')) return;
        const res = await fetch(`${base}/api/assign/unassign.php?id=${id}`, { method: 'POST' });
        if (res.ok) loadAssigned();
    });

    (async function init(){
        await loadCases();
        await loadSuspectsOptions();
        loadAssigned();
    })();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


