<?php
require_once __DIR__ . '/../config/config.php';
require_login();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Reports - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/css/styles.css">
</head>
<body>
    <div class="topbar">
        <div class="brand"><?php echo APP_NAME; ?></div>
        <?php $pg = basename(__FILE__); ?>
        <nav>
            <a class="<?php echo $pg==='dashboard.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/dashboard.php"><i class="bi bi-speedometer2"></i>Dashboard</a>
            <a class="<?php echo $pg==='suspects.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/suspects.php"><i class="bi bi-people"></i>Suspects</a>
            <a class="<?php echo $pg==='cases.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/cases.php"><i class="bi bi-folder2"></i>Cases</a>
            <a class="<?php echo $pg==='assign_suspects.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/assign_suspects.php"><i class="bi bi-link-45deg"></i>Assign</a>
            <a class="<?php echo $pg==='reports.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/reports.php"><i class="bi bi-file-earmark-text"></i>Reports</a>
            <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
            <a class="<?php echo $pg==='users.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/users.php"><i class="bi bi-people-gear"></i>Users</a>
            <?php } ?>
        </nav>
        <div class="right">
            <?php $nm = $_SESSION['name'] ?? 'User'; $rl = $_SESSION['role'] ?? ''; ?>
            <span>Welcome, <?php echo htmlspecialchars($nm); ?><?php echo $rl !== '' ? ' ('.htmlspecialchars($rl).')' : ''; ?></span>
            <button class="btn secondary" id="logoutBtn">Logout</button>
        </div>
    </div>
    <div class="container">
        <h2>Reports</h2>
        <div class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Filter by Case Status</label>
                <select id="status" class="form-select">
                    <option value="">All</option>
                    <option value="open">Open</option>
                    <option value="under_investigation">Under Investigation</option>
                    <option value="closed">Closed</option>
                </select>
            </div>
            <div class="col-md-9 text-end">
                <button id="exportCsv" class="btn btn-secondary">Export CSV</button>
                <button id="exportPdf" class="btn btn-primary">Export PDF</button>
            </div>
        </div>

        <div class="table-responsive" style="margin-top:12px;">
            <div id="reportMeta" style="font-size:13px; color:#6b7280; margin-bottom:6px;"></div>
            <table class="table table-striped" id="reportTable">
                <thead>
                    <tr>
                        <th>Case #</th>
                        <th>Case Title</th>
                        <th>Status</th>
                        <th>Suspect</th>
                        <th>National ID</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

    <script>
    const base = '<?php echo BASE_URL; ?>';
    document.getElementById('logoutBtn').addEventListener('click', async () => {
        const res = await fetch(`${base}/api/auth/logout.php`, { method: 'POST' });
        if (res.ok) window.location.href = `${base}/pages/login.php`;
    });

    async function loadReport() {
        const status = document.getElementById('status').value;
        const url = `${base}/api/reports/suspect_cases.php${status ? `?status=${encodeURIComponent(status)}` : ''}`;
        const res = await fetch(url, { cache: 'no-store' });
        const data = await res.json();
        const tbody = document.querySelector('#reportTable tbody');
        tbody.innerHTML = '';
        for (const r of data.data) {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${r.case_number}</td><td>${r.title}</td><td>${r.status}</td><td>${r.full_name}</td><td>${r.national_id ?? ''}</td>`;
            tbody.appendChild(tr);
        }
        const label = status === '' ? 'All statuses' : (status.replace('_',' '));
        document.getElementById('reportMeta').textContent = `Showing ${data.data.length} record(s) • ${label}`;
    }
    document.getElementById('status').addEventListener('change', loadReport);

    // CSV export
    document.getElementById('exportCsv').addEventListener('click', async () => {
        const status = document.getElementById('status').value;
        window.location.href = `${base}/api/reports/suspect_cases_csv.php${status ? `?status=${encodeURIComponent(status)}` : ''}`;
    });

    // PDF export
    document.getElementById('exportPdf').addEventListener('click', async () => {
        const status = document.getElementById('status').value;
        window.location.href = `${base}/api/reports/suspect_cases_pdf.php${status ? `?status=${encodeURIComponent(status)}` : ''}`;
    });

    loadReport();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


