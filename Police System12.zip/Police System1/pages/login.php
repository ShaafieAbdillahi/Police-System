<?php
require_once __DIR__ . '/../config/config.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/pages/dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/css/styles.css">
    <style>
    /* Keep layout unchanged; only apply colors/background/underline per requested style */
    body.centered{
        min-height:100vh;
        background-color:#0b1e3a;
        background-image: url('<?php echo BASE_URL; ?>/public/css/images/building_bg.jpg');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }
    body.centered::after{
        content:"";
        position:fixed; inset:0; background:rgba(7,14,26,0.55); pointer-events:none;
    }
    .auth-card h1{ color:#1d4ed8; display:inline-block; padding-bottom:0; margin-bottom:6px; }
    .auth-card h2{ color:#1d4ed8; font-weight:600; }
    </style>
</head>
<body class="centered" style="position:relative;">
    <div style="position:fixed; inset:0; background-image:url('<?php echo BASE_URL; ?>/public/css/images/somali_police_logo.png'); background-repeat:no-repeat; background-position:center; background-size:420px; opacity:0.12; pointer-events:none; z-index:0;"></div>
    <div class="login-brand" style="position:absolute; top:24px; left:50%; transform:translateX(-50%); width:92%; max-width:980px; z-index:1;">
        <div style="display:flex; align-items:center; gap:12px; color:#fff;">
            <img src="<?php echo BASE_URL; ?>/public/css/images/somali_police_logo.png" alt="Logo" style="width:48px; height:48px; object-fit:contain; filter: drop-shadow(0 1px 2px rgba(0,0,0,0.5));" />
            <div>
                <div style="font-size:20px; font-weight:700; letter-spacing:0.5px; text-transform:uppercase;">Police Suspect Management System</div>
            </div>
        </div>
        <div style="height:2px; background:#b91c1c; margin-top:8px; width:100%;"></div>
    </div>
    <div class="card auth-card" style="position:relative; z-index:1; overflow:hidden;">
        <div style="position:absolute; inset:0; background-image:url('<?php echo BASE_URL; ?>/public/css/images/somali_police_logo.png'); background-repeat:no-repeat; background-position:center; background-size:70%; opacity:0.18; pointer-events:none;"></div>
        <h1><?php echo APP_NAME; ?></h1>
        <h2>Login</h2>
        <div class="btn-group w-100" role="group" aria-label="Role selector" style="margin-bottom:8px;">
            <input type="radio" class="btn-check" name="role" id="role_admin" value="admin" autocomplete="off">
            <label class="btn btn-outline-primary" for="role_admin">Admin</label>
            <input type="radio" class="btn-check" name="role" id="role_officer" value="officer" autocomplete="off" checked>
            <label class="btn btn-outline-primary" for="role_officer">Officer</label>
            <input type="radio" class="btn-check" name="role" id="role_investigator" value="investigator" autocomplete="off">
            <label class="btn btn-outline-primary" for="role_investigator">Investigator</label>
        </div>
        <form id="loginForm" class="mt-2">
            <label class="form-label">Username</label>
            <input class="form-control" type="text" name="username" id="username" placeholder="your username" required />
            <label class="form-label">Password</label>
            <input class="form-control" type="password" name="password" id="password" placeholder="••••••••" required />
            <div class="d-flex justify-content-between align-items-center mt-3">
                <button type="button" id="forgotBtn" class="btn btn-link p-0">Forgot password?</button>
                <button type="submit" class="btn btn-primary">Login</button>
            </div>
        </form>
        <div id="loginError" class="error" style="display:none;"></div>
    </div>

    <script>
    const form = document.getElementById('loginForm');
    const err = document.getElementById('loginError');
    const forgotBtn = document.getElementById('forgotBtn');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        err.style.display = 'none';
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const role = (document.querySelector('input[name="role"]:checked')?.value) || '';
        try {
            const res = await fetch('<?php echo BASE_URL; ?>/api/auth/login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, role })
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Login failed');
            window.location.href = '<?php echo BASE_URL; ?>/pages/dashboard.php';
        } catch (e) {
            err.textContent = e.message;
            err.style.display = 'block';
        }
    });

    forgotBtn.addEventListener('click', async () => {
        const identifier = prompt('Enter your username or email to request a reset:');
        if (!identifier) return;
        try {
            const res = await fetch('<?php echo BASE_URL; ?>/api/auth/forgot.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ identifier })
            });
            const data = await res.json();
            alert(data.message || 'Request submitted.');
        } catch (e) {
            alert('Failed to submit request.');
        }
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


