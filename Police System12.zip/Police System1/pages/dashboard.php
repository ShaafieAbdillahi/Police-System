<?php
require_once __DIR__ . '/../config/config.php';
require_login();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/css/styles.css">
    <style>
    /* Dashboard enhancements: glass cards and nav icons spacing */
    .white-card{ background:#ffffff; border: 1px solid rgba(0,0,0,0.06); border-radius: 10px; box-shadow: 0 6px 18px rgba(0,0,0,0.12); padding: 12px; }
    .glass-title{ color:#111827; font-weight:600; font-size:16px; display:flex; align-items:center; gap:8px; margin:0; }
    .glass-sub{ color:#6b7280; font-size:12px; }
    .topbar nav a i{ margin-right:6px; opacity:0.9; }
    canvas#trend{ background: transparent; }
    .chart-legend{ display:flex; gap:12px; font-size:12px; color:#6b7280; margin-top:4px; }
    </style>
</head>
<body>
    <style>
    .bg-watermark{
        position: fixed; inset: 0; z-index: 0;
        background-image: url('<?php echo BASE_URL; ?>/public/css/images/police.jpeg');
        background-size: cover; background-position: center; background-repeat: no-repeat;
        opacity: 0.36; /* increase visibility */
        filter: blur(3px) saturate(1.05); /* lighter blur, slight saturation */
        pointer-events: none;
    }
    .topbar, .container { position: relative; z-index: 1; }
    </style>
    <div class="bg-watermark"></div>
    <style>
    /* subtle blue gradient overlay to enhance the blue glassy feel */
    .bg-blue-tint{ position: fixed; inset:0; z-index: 0; pointer-events:none;
        background: radial-gradient(1200px 800px at 20% 10%, rgba(59,130,246,0.22), transparent 62%),
                    radial-gradient(1000px 700px at 80% 70%, rgba(29,78,216,0.24), transparent 62%);
    }
    </style>
    <div class="bg-blue-tint"></div>
    <div class="topbar">
        <div class="brand"><?php echo APP_NAME; ?></div>
        <nav>
            <a href="<?php echo BASE_URL; ?>/pages/dashboard.php"><i class="bi bi-speedometer2"></i>Dashboard</a>
            <a href="<?php echo BASE_URL; ?>/pages/suspects.php"><i class="bi bi-people"></i>Suspects</a>
            <a href="<?php echo BASE_URL; ?>/pages/cases.php"><i class="bi bi-folder2"></i>Cases</a>
            <a href="<?php echo BASE_URL; ?>/pages/assign_suspects.php"><i class="bi bi-link-45deg"></i>Assign</a>
            <a href="<?php echo BASE_URL; ?>/pages/reports.php"><i class="bi bi-file-earmark-text"></i>Reports</a>
            <a href="<?php echo BASE_URL; ?>/pages/profile.php"><i class="bi bi-person-circle"></i>Profile</a>
            <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
            <a href="<?php echo BASE_URL; ?>/pages/users.php"><i class="bi bi-people-gear"></i>Users</a>
            <?php } ?>
        </nav>
        <div class="right">
            <?php $nm = $_SESSION['name'] ?? 'User'; $rl = $_SESSION['role'] ?? ''; ?>
            <span>Welcome, <?php echo htmlspecialchars($nm); ?><?php echo $rl !== '' ? ' ('.htmlspecialchars($rl).')' : ''; ?></span>
            <button class="btn secondary" id="logoutBtn">Logout</button>
        </div>
    </div>
    <div class="container">
        <main>
                <div class="last-updated">Last updated: <span id="lastUpdated"></span></div>
                <div class="stats" id="cards" style="align-items: stretch;"></div>
                <div style="margin-top:16px; display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:12px;">
                    <div class="stat">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <h3 style="margin:0; font-size:16px;">Recent Suspects</h3>
                            <a class="btn primary" href="<?php echo BASE_URL; ?>/pages/suspects.php">View</a>
                        </div>
                        <ul id="recentSuspects" style="list-style:none; padding:0; margin:12px 0 0 0;">
                        </ul>
                    </div>
                    <div class="stat">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <h3 style="margin:0; font-size:16px;">Recent Cases</h3>
                            <a class="btn primary" href="<?php echo BASE_URL; ?>/pages/cases.php">View</a>
                        </div>
                        <ul id="recentCases" style="list-style:none; padding:0; margin:12px 0 0 0;">
                        </ul>
                    </div>
                    <div class="white-card">
                        <div class="glass-title"><i class="bi bi-graph-up"></i> New Suspects (7 days)</div>
                        <div class="glass-sub">Daily totals for the past week</div>
                        <canvas id="trend" width="440" height="140" style="width:100%; height:140px; margin-top:8px;"></canvas>
                        <div class="chart-legend"><span><span style="display:inline-block;width:10px;height:10px;background:#3b82f6; border-radius:2px; margin-right:6px;"></span>Suspects</span></div>
                    </div>
                    <div class="stat">
                        <h3 style="margin:0; font-size:16px;">Cases by Status</h3>
                        <canvas id="statusDonut" width="220" height="160" style="width:100%; height:160px; margin-top:8px;"></canvas>
                    </div>
                    <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                    <div class="stat">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <h3 style="margin:0; font-size:16px;">Recent Activity</h3>
                        </div>
                        <div class="table-responsive" style="margin-top:8px;">
                            <table class="table table-compact table-hover" id="loginAttemptsTable">
                                <thead>
                                    <tr>
                                        <th class="sticky">User</th>
                                        <th class="sticky">Action</th>
                                        <th class="sticky nowrap">Time</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <?php } ?>
                </div>
        </main>
    </div>
    <script>
    document.getElementById('logoutBtn').addEventListener('click', async () => {
        const res = await fetch('<?php echo BASE_URL; ?>/api/auth/logout.php', { method: 'POST' });
        if (res.ok) window.location.href = '<?php echo BASE_URL; ?>/pages/login.php';
    });

    async function loadSummary() {
        const res = await fetch('<?php echo BASE_URL; ?>/api/dashboard/summary.php');
        const data = await res.json();
        const t = data.totals;
        const cards = [
            { label: 'Total Suspects', value: t.suspects },
            { label: 'Total Cases', value: t.cases },
            { label: 'Open Cases', value: t.open_cases },
            { label: 'Closed Cases', value: t.closed_cases },
            { label: 'Under Investigation', value: t.under_investigation },
        ];
        const cardsEl = document.getElementById('cards');
        cardsEl.innerHTML = '';
        const classMap = {
            'Total Suspects': 'card-blue',
            'Total Cases': 'card-indigo',
            'Open Cases': 'card-green',
            'Closed Cases': 'card-yellow',
            'Under Investigation': 'card-red',
        };
        for (const c of cards) {
            const div = document.createElement('div');
            const accent = classMap[c.label] || 'card-blue';
            div.className = `stat ${accent}`;
            div.innerHTML = `<div style="font-size:13px; color:#6b7280;">${c.label}</div><div style="font-size:28px; font-weight:700; margin-top:6px;">${c.value}</div>`;
            cardsEl.appendChild(div);
        }
        drawTrend(data.trend || []);
        document.getElementById('lastUpdated').textContent = new Date().toLocaleString();
        drawStatusDonut({ open: t.open_cases, closed: t.closed_cases, under: t.under_investigation });
    }

    async function loadRecent() {
        const res = await fetch('<?php echo BASE_URL; ?>/api/dashboard/recent.php');
        const data = await res.json();
        const rs = document.getElementById('recentSuspects');
        rs.innerHTML = '';
        for (const s of data.suspects) {
            const li = document.createElement('li');
            li.style.padding = '8px 0';
            li.style.borderBottom = '1px solid #f3f4f6';
            li.textContent = `${s.full_name} (#${s.id})`;
            rs.appendChild(li);
        }
        const rc = document.getElementById('recentCases');
        rc.innerHTML = '';
        for (const c of data.cases) {
            const li = document.createElement('li');
            li.style.padding = '8px 0';
            li.style.borderBottom = '1px solid #f3f4f6';
            li.textContent = `${c.case_number} - ${c.title} [${c.status}]`;
            rc.appendChild(li);
        }
    }

    function drawTrend(points) {
        const canvas = document.getElementById('trend');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (!points || points.length === 0) return;
        const values = points.map(p => parseInt(p.c, 10));
        const labels = points.map(p => p.d || '');
        const max = Math.max(2, ...values);
        const padding = 26;
        const chartW = canvas.width - padding * 2;
        const chartH = canvas.height - padding * 2;
        const barW = Math.max(10, Math.floor(chartW / (values.length * 1.6)));
        const gap = Math.max(8, Math.floor((chartW - barW * values.length) / Math.max(1, values.length - 1)));

        // Grid lines
        ctx.strokeStyle = 'rgba(0,0,0,0.08)';
        ctx.lineWidth = 1;
        for (let i=0;i<=4;i++){
            const y = padding + (chartH/4)*i;
            ctx.beginPath(); ctx.moveTo(padding, y); ctx.lineTo(canvas.width - padding, y); ctx.stroke();
        }

        // Bars
        for (let i=0;i<values.length;i++){
            const x = padding + i * (barW + gap);
            const h = (values[i] / max) * chartH;
            const y = canvas.height - padding - h;
            const grd = ctx.createLinearGradient(0, y, 0, y+h);
            grd.addColorStop(0, '#60a5fa');
            grd.addColorStop(1, '#1d4ed8');
            ctx.fillStyle = grd;
            ctx.fillRect(x, y, barW, h);
        }

        // X labels
        ctx.fillStyle = '#374151';
        ctx.font = '11px Arial';
        ctx.textAlign = 'center';
        for (let i=0;i<labels.length;i++){
            const x = padding + i * (barW + gap) + barW/2;
            const text = (labels[i]+'').slice(5);
            const textY = canvas.height - 6;
            ctx.fillText(text, x, textY);
            // underline the label
            const metricsWidth = ctx.measureText(text).width;
            const underlineY = textY + 2;
            ctx.beginPath();
            ctx.moveTo(x - metricsWidth/2, underlineY);
            ctx.lineTo(x + metricsWidth/2, underlineY);
            ctx.strokeStyle = '#374151';
            ctx.lineWidth = 1;
            ctx.stroke();
        }
    }

    loadSummary();
    loadRecent();
    <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
    loadLoginAttempts();
    <?php } ?>

    function drawStatusDonut(counts){
        const canvas = document.getElementById('statusDonut');
        if(!canvas) return;
        const ctx = canvas.getContext('2d');
        const total = Math.max(1, (counts.open||0)+(counts.closed||0)+(counts.under||0));
        const parts = [
            { value: counts.open||0, color:'#10b981', label:'Open' },
            { value: counts.under||0, color:'#f59e0b', label:'Under' },
            { value: counts.closed||0, color:'#6366f1', label:'Closed' },
        ];
        let start = -Math.PI/2;
        ctx.clearRect(0,0,canvas.width,canvas.height);
        const cx = canvas.width/2, cy = canvas.height/2, r = Math.min(cx, cy)-10;
        for(const p of parts){
            const angle = (p.value/total)*Math.PI*2;
            ctx.beginPath();
            ctx.moveTo(cx,cy);
            ctx.arc(cx,cy,r,start,start+angle);
            ctx.closePath();
            ctx.fillStyle = p.color; ctx.fill();
            start += angle;
        }
        // cut hole
        ctx.globalCompositeOperation = 'destination-out';
        ctx.beginPath(); ctx.arc(cx,cy,r*0.6,0,Math.PI*2); ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = '#374151';
        ctx.font = 'bold 14px Arial';
        ctx.textAlign='center'; ctx.textBaseline='middle';
        ctx.fillText('Cases', cx, cy);
    }

    async function loadLoginAttempts(){
        try{
            const res = await fetch('<?php echo BASE_URL; ?>/api/auth/activities.php?limit=10');
            const data = await res.json();
            const tbody = document.querySelector('#loginAttemptsTable tbody');
            tbody.innerHTML = '';
            for(const r of data.data){
                const name = r.user_name || r.user_email || '';
                const action = r.action_text || r.action;
                const when = r.created_at || '';
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="truncate" title="${name}">${name}</td>
                    <td>${action}</td>
                    <td class="nowrap">${when}</td>
                `;
                tbody.appendChild(tr);
            }
        }catch(e){ /* ignore */ }
    }
    </script>
</body>
</html>


