<?php
require_once __DIR__ . '/../config/config.php';
require_login();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Cases - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/css/styles.css">
</head>
<body>
    <div class="topbar">
        <div class="brand"><?php echo APP_NAME; ?></div>
        <?php $pg = basename(__FILE__); ?>
        <nav>
            <a class="<?php echo $pg==='dashboard.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/dashboard.php"><i class="bi bi-speedometer2"></i>Dashboard</a>
            <a class="<?php echo $pg==='suspects.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/suspects.php"><i class="bi bi-people"></i>Suspects</a>
            <a class="<?php echo $pg==='cases.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/cases.php"><i class="bi bi-folder2"></i>Cases</a>
            <a class="<?php echo $pg==='assign_suspects.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/assign_suspects.php"><i class="bi bi-link-45deg"></i>Assign</a>
            <a class="<?php echo $pg==='reports.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/reports.php"><i class="bi bi-file-earmark-text"></i>Reports</a>
            <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
            <a class="<?php echo $pg==='users.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>/pages/users.php"><i class="bi bi-people-gear"></i>Users</a>
            <?php } ?>
        </nav>
        <div class="right">
            <?php $nm = $_SESSION['name'] ?? 'User'; $rl = $_SESSION['role'] ?? ''; ?>
            <span>Welcome, <?php echo htmlspecialchars($nm); ?><?php echo $rl !== '' ? ' ('.htmlspecialchars($rl).')' : ''; ?></span>
            <button class="btn secondary" id="logoutBtn">Logout</button>
        </div>
    </div>
    <div class="container">
        <div id="successMsg" class="alert alert-success" style="display:none; margin-bottom:8px;"></div>
        <div class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Search</label>
                <input id="search" class="form-control" placeholder="case number or title" />
            </div>
            <div class="col-md-9 text-end">
                <button class="btn btn-primary" id="addBtn">Add Case</button>
            </div>
        </div>

        <div class="table-responsive" style="margin-top:12px;">
            <table class="table table-striped table-hover table-compact" id="casesTable">
                <thead>
                    <tr>
                        <th class="sticky">ID</th>
                        <th class="sticky nowrap">Case #</th>
                        <th class="sticky">Title</th>
                        <th class="sticky nowrap">Status</th>
                        <?php if (!empty($_SESSION['role']) && $_SESSION['role'] !== 'investigator') { ?>
                        <th class="sticky nowrap">Updated</th>
                        <th>Actions</th>
                        <?php } ?>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
        <div class="row" style="margin-top:16px;">
            <div class="col-md-6">
                <div class="stat">
                    <h4>Evidence</h4>
                    <form id="evidenceForm" class="row g-2">
                        <input type="hidden" id="e_case_id" />
                        <div class="col-8"><input type="file" class="form-control" id="e_file" /></div>
                        <div class="col-4"><button class="btn btn-primary w-100" type="submit">Upload</button></div>
                        <div class="col-12"><input id="e_notes" class="form-control" placeholder="Notes (optional)" /></div>
                    </form>
                    <div class="table-responsive" style="margin-top:8px;">
                        <table class="table table-sm" id="evidenceTable"><thead><tr><th>File</th><th>Size</th><th>Uploaded</th><th>Actions</th></tr></thead><tbody></tbody></table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="stat">
                    <h4>Timeline</h4>
                    <form id="eventForm" class="row g-2">
                        <input type="hidden" id="ev_case_id" />
                        <div class="col-4"><input id="ev_type" class="form-control" placeholder="Event type" required /></div>
                        <div class="col-8"><input id="ev_desc" class="form-control" placeholder="Description (optional)" /></div>
                        <div class="col-12"><button class="btn btn-secondary" type="submit">Add Event</button></div>
                    </form>
                    <ul id="eventsList" style="list-style:none; padding:0; margin-top:8px;"></ul>
                </div>
            </div>
        </div>
    </div>

    <dialog id="caseDialog">
        <form method="dialog" id="caseForm" class="p-2" style="min-width:380px;">
            <h3 id="dlgTitle" class="mb-2">Add Case</h3>
            <input type="hidden" id="caseId" />
            <div class="row g-2">
                <div class="col-md-6">
                    <label class="form-label">Case Number</label>
                    <input id="case_number" class="form-control" placeholder="e.g. CN-2025-001" required />
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select id="status" class="form-select">
                        <option value="open">Open</option>
                        <option value="under_investigation">Under Investigation</option>
                        <option value="closed">Closed</option>
                    </select>
                </div>
            </div>
            <div class="mb-2">
                <label class="form-label">Title</label>
                <input id="title" class="form-control" placeholder="Short case title" required />
            </div>
            <div class="mb-2">
                <label class="form-label">Description</label>
                <textarea id="description" class="form-control" rows="3" placeholder="Optional details"></textarea>
            </div>
            <div class="d-flex gap-2 mt-3">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="button" id="cancelDlg" class="btn btn-secondary">Cancel</button>
            </div>
            <div id="formError" class="error" style="display:none; margin-top:8px;"></div>
        </form>
    </dialog>

    <script>
    const base = '<?php echo BASE_URL; ?>';
    const CAN_MANAGE = <?php echo (!empty($_SESSION['role']) && in_array($_SESSION['role'], ['admin','officer'], true)) ? 'true' : 'false'; ?>;
    const IS_INVESTIGATOR = <?php echo (!empty($_SESSION['role']) && $_SESSION['role'] === 'investigator') ? 'true' : 'false'; ?>;
    document.getElementById('logoutBtn').addEventListener('click', async () => {
        const res = await fetch(`${base}/api/auth/logout.php`, { method: 'POST' });
        if (res.ok) window.location.href = `${base}/pages/login.php`;
    });

    const tbody = document.querySelector('#casesTable tbody');
    const search = document.getElementById('search');
    const successMsg = document.getElementById('successMsg');
    function showSuccess(message){
        if(!successMsg) return;
        successMsg.textContent = message;
        successMsg.style.display = 'block';
        setTimeout(()=>{ successMsg.style.display = 'none'; }, 3000);
    }
    async function loadCases() {
        const q = search.value.trim();
        const res = await fetch(`${base}/api/cases/list.php${q ? `?q=${encodeURIComponent(q)}` : ''}`);
        const data = await res.json();
        tbody.innerHTML = '';
        for (const c of data.data) {
            const tr = document.createElement('tr');
            tr.setAttribute('data-id', String(c.id));
            const actions = CAN_MANAGE ? `<button class=\"btn secondary\" data-edit=\"${c.id}\">Edit</button> <button class=\"btn danger\" data-del=\"${c.id}\">Delete</button>` : '';
            const cols = [
                `<td>${c.id}</td>`,
                `<td class=\"nowrap\">${c.case_number}</td>`,
                `<td class=\"truncate\" title=\"${c.title}\">${c.title}</td>`,
                `<td class=\"nowrap\">${c.status}</td>`
            ];
            if (!IS_INVESTIGATOR) {
                cols.push(`<td class=\"nowrap\">${c.updated_at ?? ''}</td>`);
                cols.push(`<td class=\"actions\">${actions}</td>`);
            }
            tr.innerHTML = cols.join('');
            tbody.appendChild(tr);
        }
    }
    search.addEventListener('input', () => loadCases());

    const dlg = document.getElementById('caseDialog');
    const form = document.getElementById('caseForm');
    const errorBox = document.getElementById('formError');
    document.getElementById('addBtn').addEventListener('click', () => {
        form.reset();
        document.getElementById('caseId').value = '';
        document.getElementById('dlgTitle').textContent = 'Add Case';
        errorBox.style.display = 'none';
        dlg.showModal();
    });
    document.getElementById('cancelDlg').addEventListener('click', () => dlg.close());

    tbody.addEventListener('click', async (e) => {
        const editId = e.target.getAttribute('data-edit');
        const delId = e.target.getAttribute('data-del');
        // Row select to load Evidence and Timeline for all roles
        const tr = e.target.closest('tr');
        if (tr && !editId && !delId) {
            const rowId = tr.getAttribute('data-id');
            if (rowId) {
                document.getElementById('e_case_id').value = rowId;
                document.getElementById('ev_case_id').value = rowId;
                await loadEvidence();
                await loadEvents();
            }
        }
        if (editId) {
            const tr = e.target.closest('tr');
            document.getElementById('caseId').value = editId;
            document.getElementById('e_case_id').value = editId;
            document.getElementById('ev_case_id').value = editId;
            document.getElementById('case_number').value = tr.children[1].textContent;
            document.getElementById('title').value = tr.children[2].textContent;
            document.getElementById('status').value = tr.children[3].textContent;
            document.getElementById('dlgTitle').textContent = 'Edit Case';
            errorBox.style.display = 'none';
            dlg.showModal();
            loadEvidence();
            loadEvents();
        }
        if (delId) {
            if (!confirm('Delete this case?')) return;
            const res = await fetch(`${base}/api/cases/delete.php?id=${delId}`, { method: 'POST' });
            if (res.ok) { showSuccess('Case deleted successfully'); loadCases(); }
        }
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        errorBox.style.display = 'none';
        const payload = {
            case_number: document.getElementById('case_number').value.trim(),
            title: document.getElementById('title').value.trim(),
            description: document.getElementById('description').value.trim(),
            status: document.getElementById('status').value,
        };
        const id = document.getElementById('caseId').value;
        let url = `${base}/api/cases/create.php`;
        let method = 'POST';
        if (id) {
            url = `${base}/api/cases/update.php`;
            payload.id = id;
        }
        try {
            const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Request failed');
            dlg.close();
            const isUpdate = !!document.getElementById('caseId').value;
            showSuccess(isUpdate ? 'Case updated successfully' : 'Case added successfully');
            await loadCases();
        } catch (err) {
            errorBox.textContent = err.message;
            errorBox.style.display = 'block';
        }
    });

    loadCases();

    async function loadEvidence(){
        const cid = document.getElementById('e_case_id').value;
        if(!cid) return;
        const res = await fetch(`${base}/api/evidence/list.php?case_id=${cid}`);
        const data = await res.json();
        const tbody = document.querySelector('#evidenceTable tbody');
        tbody.innerHTML = '';
        for(const f of data.data){
            const tr = document.createElement('tr');
            const size = f.size_bytes ? Math.round(f.size_bytes/1024)+' KB' : '';
            tr.innerHTML = `<td>${f.filename}</td><td>${size}</td><td>${f.created_at}</td><td><a class="btn btn-sm btn-secondary" href="${base}/api/evidence/download.php?id=${f.id}">Download</a> <button class="btn btn-sm btn-danger" data-del-ev="${f.id}">Delete</button></td>`;
            tbody.appendChild(tr);
        }
    }
    document.querySelector('#evidenceTable').addEventListener('click', async (e)=>{
        const id = e.target.getAttribute('data-del-ev');
        if(!id) return;
        if(!confirm('Delete this file?')) return;
        const res = await fetch(`${base}/api/evidence/delete.php?id=${id}`, { method:'POST' });
        if(res.ok) loadEvidence();
    });
    document.getElementById('evidenceForm').addEventListener('submit', async (e)=>{
        e.preventDefault();
        const cid = document.getElementById('e_case_id').value;
        const file = document.getElementById('e_file').files[0];
        const notes = document.getElementById('e_notes').value;
        if(!cid || !file) return;
        const fd = new FormData();
        fd.append('case_id', cid);
        fd.append('file', file);
        fd.append('notes', notes);
        const res = await fetch(`${base}/api/evidence/upload.php`, { method:'POST', body: fd });
        if(res.ok){ document.getElementById('e_file').value=''; document.getElementById('e_notes').value=''; loadEvidence(); }
    });

    async function loadEvents(){
        const cid = document.getElementById('ev_case_id').value;
        if(!cid) return;
        const res = await fetch(`${base}/api/case_events/list.php?case_id=${cid}`);
        const data = await res.json();
        const ul = document.getElementById('eventsList');
        ul.innerHTML = '';
        for(const ev of data.data){
            const li = document.createElement('li');
            li.style.padding = '6px 0';
            li.style.borderBottom = '1px solid #f3f4f6';
            li.textContent = `${ev.created_at} — ${ev.event_type}${ev.description ? ': ' + ev.description : ''}`;
            ul.appendChild(li);
        }
    }
    document.getElementById('eventForm').addEventListener('submit', async (e)=>{
        e.preventDefault();
        const cid = document.getElementById('ev_case_id').value;
        const event_type = document.getElementById('ev_type').value.trim();
        const description = document.getElementById('ev_desc').value.trim();
        if(!cid || !event_type) return;
        const res = await fetch(`${base}/api/case_events/create.php`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ case_id: cid, event_type, description }) });
        if(res.ok){ document.getElementById('ev_type').value=''; document.getElementById('ev_desc').value=''; loadEvents(); }
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


