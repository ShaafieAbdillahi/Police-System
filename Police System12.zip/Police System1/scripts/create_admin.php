<?php
// TEMPORARY seeding script. Run once, then delete this file.
require_once __DIR__ . '/../db/Database.php';

$pdo = Database::connection();
$email = 'admin@local';
$name = 'Administrator';
$role = 'admin';
$plain = 'admin123';
$hash = password_hash($plain, PASSWORD_BCRYPT);

$pdo->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), password = VALUES(password), role = VALUES(role)')
    ->execute([$name, $email, $hash, $role]);

header('Content-Type: text/plain');
echo "Admin ensured/updated.\nEmail: $email\nPassword: $plain\nRole: $role\n";


