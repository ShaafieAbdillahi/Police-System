<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';

$pdo = Database::connection();

$totals = [
    'suspects' => 0,
    'cases' => 0,
    'open_cases' => 0,
    'closed_cases' => 0,
    'under_investigation' => 0,
];

$totals['suspects'] = (int)$pdo->query('SELECT COUNT(*) c FROM suspects')->fetch()['c'];
$totals['cases'] = (int)$pdo->query('SELECT COUNT(*) c FROM cases')->fetch()['c'];
$totals['open_cases'] = (int)$pdo->query("SELECT COUNT(*) c FROM cases WHERE status='open'")->fetch()['c'];
$totals['closed_cases'] = (int)$pdo->query("SELECT COUNT(*) c FROM cases WHERE status='closed'")->fetch()['c'];
$totals['under_investigation'] = (int)$pdo->query("SELECT COUNT(*) c FROM cases WHERE status='under_investigation'")->fetch()['c'];

// Simple trend: suspects added last 7 days
$trendStmt = $pdo->query("SELECT DATE(created_at) d, COUNT(*) c FROM suspects WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) GROUP BY DATE(created_at) ORDER BY d ASC");
$trend = $trendStmt->fetchAll();

json_response(['totals' => $totals, 'trend' => $trend]);


