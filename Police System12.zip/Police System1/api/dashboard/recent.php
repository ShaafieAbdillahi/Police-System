<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';

$pdo = Database::connection();
$recentSuspects = $pdo->query('SELECT id, full_name, created_at FROM suspects ORDER BY id DESC LIMIT 5')->fetchAll();
$recentCases = $pdo->query('SELECT id, case_number, title, status, created_at FROM cases ORDER BY id DESC LIMIT 5')->fetchAll();

json_response(['suspects' => $recentSuspects, 'cases' => $recentCases]);


