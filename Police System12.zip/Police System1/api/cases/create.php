<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_once __DIR__ . '/../../db/Database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

require_permission('cases.create');

$input = json_decode(file_get_contents('php://input'), true) ?? [];

$case_number = trim($input['case_number'] ?? '');
$title = trim($input['title'] ?? '');
$description = trim($input['description'] ?? '');
$status = trim($input['status'] ?? 'open');

if ($case_number === '' || $title === '') {
    json_response(['error' => 'Case number and title are required'], 422);
}
if (!in_array($status, ['open','closed','under_investigation'], true)) {
    json_response(['error' => 'Invalid status'], 422);
}

$pdo = Database::connection();
try {
    $stmt = $pdo->prepare('INSERT INTO cases (case_number, title, description, status) VALUES (?,?,?,?)');
    $stmt->execute([
        $case_number,
        $title,
        $input['description'] ?? null,
        $input['status'] ?? 'open',
    ]);
    $id = (int)$pdo->lastInsertId();

    log_activity('create_case', 'case', $id, ['case_number'=>$case_number,'title'=>$title]);

    json_response(['message'=>'Created','id'=>$id]);
} catch (PDOException $e) {
    if ($e->errorInfo[1] === 1062) {
        json_response(['error' => 'Case number already exists'], 409);
    }
    throw $e;
}


