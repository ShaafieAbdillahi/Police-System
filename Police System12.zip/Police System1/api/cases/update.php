<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_once __DIR__ . '/../../db/Database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'PUT') {
    json_response(['error' => 'Method not allowed'], 405);
}

require_permission('cases.edit');

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$id = (int)($input['id'] ?? ($_GET['id'] ?? 0));
if ($id <= 0) json_response(['error' => 'Invalid id'], 422);

$fields = ['case_number','title','description','status'];
$updates = [];
$values = [];
foreach ($fields as $f) {
    if (array_key_exists($f, $input)) {
        $updates[] = "$f = ?";
        $v = trim((string)$input[$f]);
        if ($f === 'status' && $v !== '' && !in_array($v, ['open','closed','under_investigation'], true)) {
            json_response(['error' => 'Invalid status'], 422);
        }
        $values[] = ($v !== '') ? $v : null;
    }
}
if (count($updates) === 0) json_response(['error' => 'No fields to update'], 422);

$values[] = $id;
$pdo = Database::connection();
$sql = 'UPDATE cases SET ' . implode(', ', $updates) . ' WHERE id = ?';
$stmt = $pdo->prepare($sql);
$stmt->execute($values);

// Log activity with changed fields metadata
try {
    require_once __DIR__ . '/../_permissions.php';
    $changedFields = [];
    foreach ($fields as $f) {
        if (array_key_exists($f, $input)) {
            $changedFields[$f] = $input[$f];
        }
    }
    log_activity('update_case', 'case', $id, ['changed' => $changedFields]);
} catch (Throwable $e) { /* ignore */ }

json_response(['message' => 'Case updated']);


