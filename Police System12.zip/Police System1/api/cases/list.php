<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';

$pdo = Database::connection();
$q = isset($_GET['q']) ? '%' . trim($_GET['q']) . '%' : null;
if ($q) {
    $stmt = $pdo->prepare("SELECT id, case_number, title, status, created_at, updated_at FROM cases WHERE case_number LIKE ? OR title LIKE ? ORDER BY id DESC");
    $stmt->execute([$q, $q]);
} else {
    $stmt = $pdo->query('SELECT id, case_number, title, status, created_at, updated_at FROM cases ORDER BY id DESC');
}
json_response(['data' => $stmt->fetchAll()]);


