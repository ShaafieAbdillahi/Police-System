<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_once __DIR__ . '/../../db/Database.php';
require_permission('evidence.manage');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    json_response(['error' => 'Method not allowed'], 405);
}
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) json_response(['error' => 'Invalid id'], 422);

$pdo = Database::connection();
$stmt = $pdo->prepare('SELECT stored_name FROM evidence WHERE id = ?');
$stmt->execute([$id]);
$row = $stmt->fetch();
if ($row) {
    @unlink(__DIR__ . '/../../storage/evidence/' . $row['stored_name']);
}
$pdo->prepare('DELETE FROM evidence WHERE id = ?')->execute([$id]);
json_response(['message' => 'Deleted']);


