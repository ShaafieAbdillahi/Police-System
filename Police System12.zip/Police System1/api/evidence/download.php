<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) json_response(['error' => 'Invalid id'], 422);

$pdo = Database::connection();
$stmt = $pdo->prepare('SELECT filename, stored_name, mime_type FROM evidence WHERE id = ? LIMIT 1');
$stmt->execute([$id]);
$row = $stmt->fetch();
if (!$row) json_response(['error' => 'Not found'], 404);

$path = __DIR__ . '/../../storage/evidence/' . $row['stored_name'];
if (!file_exists($path)) json_response(['error' => 'File missing'], 404);

header('Content-Type: ' . ($row['mime_type'] ?: 'application/octet-stream'));
header('Content-Disposition: attachment; filename="' . basename($row['filename']) . '"');
readfile($path);
exit;


