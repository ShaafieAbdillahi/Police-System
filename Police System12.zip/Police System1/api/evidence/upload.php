<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_once __DIR__ . '/../../db/Database.php';
require_permission('evidence.manage');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

$case_id = (int)($_POST['case_id'] ?? 0);
if ($case_id <= 0) json_response(['error' => 'Invalid case_id'], 422);

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    json_response(['error' => 'No file uploaded'], 400);
}

$uploadDir = __DIR__ . '/../../storage/evidence';
if (!is_dir($uploadDir)) { @mkdir($uploadDir, 0777, true); }

$original = $_FILES['file']['name'];
$stored = uniqid('evi_', true) . '_' . preg_replace('/[^A-Za-z0-9_.-]/', '_', $original);
$dest = $uploadDir . '/' . $stored;
if (!move_uploaded_file($_FILES['file']['tmp_name'], $dest)) {
    json_response(['error' => 'Failed to store file'], 500);
}

$pdo = Database::connection();
$stmt = $pdo->prepare('INSERT INTO evidence (case_id, filename, stored_name, mime_type, size_bytes, uploaded_by, notes) VALUES (?, ?, ?, ?, ?, ?, ?)');
$stmt->execute([$case_id, $original, $stored, $_FILES['file']['type'] ?? null, (int)($_FILES['file']['size'] ?? 0), (int)($_SESSION['user_id'] ?? null), $_POST['notes'] ?? null]);

json_response(['message' => 'Uploaded', 'id' => (int)$pdo->lastInsertId()]);


