<?php
require_once __DIR__ . '/../config/config.php';

function can(string $permission): bool {
    $role = $_SESSION['role'] ?? '';
    $matrix = [
        'admin' => ['*'],
        'officer' => [
            'users.view',
            'suspects.view','suspects.create','suspects.edit',
            'suspects.delete',
            'cases.view','cases.create','cases.edit','cases.delete',
            'assign.create','assign.delete',
            'evidence.manage','reports.view'
        ],
        'investigator' => [
            'suspects.view',
            'cases.view','cases.edit',
            'assign.create','assign.delete',
            'evidence.manage','reports.view'
        ],
    ];
    $allowed = $matrix[$role] ?? [];
    if (in_array('*', $allowed, true)) return true;
    return in_array($permission, $allowed, true);
}

function require_permission(string $permission): void {
    if (!can($permission)) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        exit;
    }
}

function log_activity(string $action, ?string $entityType = null, $entityId = null, $metadata = null): void {
    try {
        require_once __DIR__ . '/../db/Database.php';
        $pdo = Database::connection();
        $stmt = $pdo->prepare('INSERT INTO activities (user_id, user_name, user_email, user_role, action, entity_type, entity_id, metadata) VALUES (?,?,?,?,?,?,?,?)');
        $userId = $_SESSION['user_id'] ?? null;
        $userName = $_SESSION['name'] ?? null;
        $userEmail = $_SESSION['email'] ?? null;
        $userRole = $_SESSION['role'] ?? null;
        $metaJson = is_null($metadata) ? null : json_encode($metadata);
        $stmt->execute([$userId, $userName, $userEmail, $userRole, $action, $entityType, $entityId, $metaJson]);
    } catch (Throwable $e) { /* ignore logging errors */ }
}


