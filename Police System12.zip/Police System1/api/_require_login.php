<?php
require_once __DIR__ . '/../config/config.php';

if (empty($_SESSION['user_id'])) {
    json_response(['error' => 'Unauthorized'], 401);
}


