<?php
require_once __DIR__ . '/../../db/Database.php';
require_once __DIR__ . '/../_require_login.php';

$pdo = Database::connection();
$userId = (int)($_SESSION['user_id'] ?? 0);
$role = $_SESSION['role'] ?? '';
$limit = isset($_GET['limit']) ? max(1, min(100, (int)$_GET['limit'])) : 10;
$all = isset($_GET['all']) ? (int)$_GET['all'] : 0;

// Admins can view all activities; others see only their own
if ($role === 'admin') {
    $stmt = $pdo->prepare('SELECT id, user_name, user_email, user_role, action, entity_type, entity_id, metadata, created_at FROM activities ORDER BY id DESC LIMIT ?');
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
} else {
    $stmt = $pdo->prepare('SELECT id, user_name, user_email, user_role, action, entity_type, entity_id, metadata, created_at FROM activities WHERE user_id = ? ORDER BY id DESC LIMIT ?');
    $stmt->bindValue(1, $userId, PDO::PARAM_INT);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
}

$stmt->execute();
$rows = $stmt->fetchAll();

foreach ($rows as &$r) {
    $roleVal = $r['user_role'] ?? '';
    $meta = $r['metadata'] ? json_decode($r['metadata'], true) : [];
    if ($r['action'] === 'login') {
        $r['action_text'] = 'logged in' . ($roleVal ? (' as ' . $roleVal) : '');
    } elseif ($r['action'] === 'create_suspect') {
        $r['action_text'] = 'registered a new suspect' . (isset($meta['full_name']) ? (': ' . $meta['full_name']) : '');
    } elseif ($r['action'] === 'create_case') {
        $roleSuffix = $roleVal ? (' (' . $roleVal . ')') : '';
        $details = [];
        if (isset($meta['case_number']) && $meta['case_number'] !== '') $details[] = $meta['case_number'];
        if (isset($meta['title']) && $meta['title'] !== '') $details[] = $meta['title'];
        $detailText = count($details) ? (': ' . implode(' — ', $details)) : '';
        $r['action_text'] = 'registered a new case' . $roleSuffix . $detailText;
    } elseif ($r['action'] === 'update_case') {
        $r['action_text'] = 'updated a case';
    } elseif ($r['action'] === 'delete_case') {
        $r['action_text'] = 'deleted a case';
    } elseif ($r['action'] === 'update_suspect') {
        $r['action_text'] = 'updated a suspect';
    } elseif ($r['action'] === 'delete_suspect') {
        $r['action_text'] = 'deleted a suspect';
    } elseif ($r['action'] === 'assign_suspect') {
        $r['action_text'] = 'assigned a suspect to a case';
    } elseif ($r['action'] === 'unassign_suspect') {
        $r['action_text'] = 'removed a suspect from a case';
    } elseif ($r['action'] === 'export_csv') {
        $r['action_text'] = 'exported a CSV report';
    } elseif ($r['action'] === 'export_pdf') {
        $r['action_text'] = 'exported a PDF report';
    } else {
        $r['action_text'] = $r['action'];
    }
}

json_response(['data' => $rows]);
