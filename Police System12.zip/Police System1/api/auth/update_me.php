<?php
require_once __DIR__ . '/../../db/Database.php';
require_once __DIR__ . '/../_require_login.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$name = trim($input['name'] ?? '');
if ($name === '') json_response(['error' => 'Name is required'], 422);

$pdo = Database::connection();
$stmt = $pdo->prepare('UPDATE users SET name=? WHERE id=?');
$stmt->execute([$name, $_SESSION['user_id']]);
$_SESSION['name'] = $name;

json_response(['message' => 'Profile updated', 'name' => $name]);


