<?php
require_once __DIR__ . '/../../db/Database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$username = isset($input['username']) ? trim($input['username']) : '';
$password = $input['password'] ?? '';
$selectedRole = isset($input['role']) ? trim($input['role']) : '';

if (($username === '' && empty($input['email'])) || $password === '') {
    json_response(['error' => 'Username and password are required'], 422);
}

$pdo = Database::connection();
if ($username !== '') {
    $stmt = $pdo->prepare('SELECT id, name, email, username, password, role FROM users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
} else {
    $email = isset($input['email']) ? trim($input['email']) : '';
    $stmt = $pdo->prepare('SELECT id, name, email, username, password, role FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
}
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password'])) {
    json_response(['error' => 'Invalid credentials'], 401);
}

// If a role was selected, enforce it matches the user's role
if ($selectedRole !== '' && $selectedRole !== $user['role']) {
    json_response(['error' => 'Role mismatch for this account'], 403);
}

$_SESSION['user_id'] = (int)$user['id'];
$_SESSION['name'] = $user['name'];
$_SESSION['email'] = $user['email'];
$_SESSION['username'] = $user['username'] ?? null;
$_SESSION['role'] = $user['role'];

json_response([
    'message' => 'Login successful',
    'user' => [
        'id' => (int)$user['id'],
        'name' => $user['name'],
        'email' => $user['email'],
        'username' => $user['username'] ?? null,
        'role' => $user['role'],
    ]
]);


