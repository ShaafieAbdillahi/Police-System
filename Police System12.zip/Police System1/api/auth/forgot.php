<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../db/Database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$identifier = trim($input['identifier'] ?? ''); // username or email
if ($identifier === '') {
    json_response(['error' => 'Identifier is required'], 422);
}

$pdo = Database::connection();

// Try to find by username first, then email
$stmt = $pdo->prepare('SELECT id, name, email, username, role FROM users WHERE username = ? LIMIT 1');
$stmt->execute([$identifier]);
$user = $stmt->fetch();
if (!$user) {
    $stmt = $pdo->prepare('SELECT id, name, email, username, role FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$identifier]);
    $user = $stmt->fetch();
}

// Always respond success to avoid enumeration; but log the request if user exists
try {
    if ($user) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? null;
        // Reuse activities log
        $stmt = $pdo->prepare('INSERT INTO activities (user_id, user_name, user_email, user_role, action, entity_type, entity_id, metadata) VALUES (?,?,?,?,?,?,?,?)');
        $meta = json_encode(['type' => 'forgot_password', 'ip' => $ip, 'user_agent' => $ua]);
        $stmt->execute([(int)$user['id'], $user['name'], $user['email'], $user['role'], 'forgot_password_request', 'user', (int)$user['id'], $meta]);
    }
} catch (Throwable $e) { /* ignore */ }

json_response(['message' => 'If the account exists, an administrator will assist with resetting the password.']);



