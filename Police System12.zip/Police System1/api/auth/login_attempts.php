<?php
require_once __DIR__ . '/../../db/Database.php';
require_once __DIR__ . '/../_require_login.php';

$pdo = Database::connection();
$userId = $_SESSION['user_id'];

$limit = isset($_GET['limit']) ? max(1, min(100, (int)$_GET['limit'])) : 10;
$sql = 'SELECT la.id, la.email, la.ip_address, la.user_agent, la.success, la.created_at, u.name AS user_name
        FROM login_attempts la
        LEFT JOIN users u ON u.id = la.user_id
        WHERE la.user_id = ? OR la.email = ?
        ORDER BY la.id DESC
        LIMIT ?';
$stmt = $pdo->prepare($sql);
$stmt->bindValue(1, $userId, PDO::PARAM_INT);
$stmt->bindValue(2, $_SESSION['email'] ?? '', PDO::PARAM_STR);
$stmt->bindValue(3, $limit, PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll();

json_response(['data' => $rows]);
