<?php
require_once __DIR__ . '/../../db/Database.php';
require_once __DIR__ . '/../_require_login.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    json_response(['error' => 'No image uploaded'], 422);
}

$allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif'];
$mime = mime_content_type($_FILES['image']['tmp_name']);
if (!isset($allowed[$mime])) json_response(['error' => 'Unsupported format'], 415);

$ext = $allowed[$mime];
$dir = __DIR__ . '/../../storage/profile';
if (!is_dir($dir)) mkdir($dir, 0777, true);
$filename = 'u' . (int)$_SESSION['user_id'] . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
$dest = $dir . '/' . $filename;
if (!move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
    json_response(['error' => 'Failed to save image'], 500);
}

$relPath = '/storage/profile/' . $filename;
$pdo = Database::connection();
$pdo->prepare('UPDATE users SET profile_image=? WHERE id=?')->execute([$relPath, $_SESSION['user_id']]);

json_response(['message'=>'Uploaded','path'=>$relPath]);


