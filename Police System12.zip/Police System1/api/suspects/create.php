<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_permission('suspects.create');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];

$full_name = trim($input['full_name'] ?? '');
$national_id = trim($input['national_id'] ?? '');
$phone = trim($input['phone'] ?? '');
$address = trim($input['address'] ?? '');
$date_of_birth = trim($input['date_of_birth'] ?? '');
$gender = trim($input['gender'] ?? '');

if ($full_name === '') {
    json_response(['error' => 'Full name is required'], 422);
}

require_once __DIR__ . '/../../db/Database.php';
$pdo = Database::connection();
$stmt = $pdo->prepare('INSERT INTO suspects (full_name, national_id, phone, address, date_of_birth, gender) VALUES (?,?,?,?,?,?)');
$stmt->execute([
    $full_name,
    $national_id !== '' ? $national_id : null,
    $phone !== '' ? $phone : null,
    $address !== '' ? $address : null,
    $date_of_birth !== '' ? $date_of_birth : null,
    $gender !== '' ? $gender : null,
]);
$id = (int)$pdo->lastInsertId();

log_activity('create_suspect', 'suspect', $id, ['full_name'=>$full_name]);

json_response(['message'=>'Created','id'=>$id]);


