<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';

$pdo = Database::connection();
$q = isset($_GET['q']) ? '%' . trim($_GET['q']) . '%' : null;

if ($q) {
    $stmt = $pdo->prepare('SELECT * FROM suspects WHERE full_name LIKE ? OR national_id LIKE ? OR phone LIKE ? ORDER BY id DESC');
    $stmt->execute([$q, $q, $q]);
} else {
    $stmt = $pdo->query('SELECT * FROM suspects ORDER BY id DESC');
}

$suspects = $stmt->fetchAll();
json_response(['data' => $suspects]);


