<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_once __DIR__ . '/../../db/Database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'PUT' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

require_permission('suspects.edit');

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$id = (int)($input['id'] ?? ($_GET['id'] ?? 0));
if ($id <= 0) json_response(['error' => 'Invalid id'], 422);

$fields = ['full_name','national_id','phone','address','date_of_birth','gender'];
$updates = [];
$values = [];
foreach ($fields as $f) {
    if (array_key_exists($f, $input)) {
        $updates[] = "$f = ?";
        $v = trim((string)$input[$f]);
        $values[] = ($v !== '') ? $v : null;
    }
}
if (count($updates) === 0) {
    json_response(['error' => 'No fields to update'], 422);
}

$values[] = $id;
$pdo = Database::connection();
$sql = 'UPDATE suspects SET ' . implode(', ', $updates) . ' WHERE id = ?';
$stmt = $pdo->prepare($sql);
$stmt->execute($values);

// Log activity with changed fields
try {
    require_once __DIR__ . '/../_permissions.php';
    $changedFields = [];
    foreach ($fields as $f) {
        if (array_key_exists($f, $input)) {
            $changedFields[$f] = $input[$f];
        }
    }
    log_activity('update_suspect', 'suspect', $id, ['changed' => $changedFields]);
} catch (Throwable $e) { /* ignore */ }

json_response(['message' => 'Suspect updated']);


