<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_once __DIR__ . '/../../db/Database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

require_permission('suspects.delete');

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) json_response(['error' => 'Invalid id'], 422);

$pdo = Database::connection();
$stmt = $pdo->prepare('DELETE FROM suspects WHERE id = ?');
$stmt->execute([$id]);
// Log activity
try {
    require_once __DIR__ . '/../_permissions.php';
    log_activity('delete_suspect', 'suspect', $id);
} catch (Throwable $e) { /* ignore */ }

json_response(['message' => 'Suspect deleted']);


