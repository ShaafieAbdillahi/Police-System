<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_once __DIR__ . '/../../db/Database.php';
require_once __DIR__ . '/../../vendor/autoload.php';

$status = $_GET['status'] ?? '';
log_activity('export_pdf', 'report', null, ['type'=>'suspect_cases','status'=>$status]);

// Try Composer autoload first, then fallback to bundled lib/fpdf/fpdf.php
$fpdfLoaded = false;
$composerAutoload = __DIR__ . '/../../vendor/autoload.php';
if (file_exists($composerAutoload)) {
    require_once $composerAutoload;
    if (class_exists('FPDF')) { $fpdfLoaded = true; }
}
if (!$fpdfLoaded) {
    $fpdfPath = __DIR__ . '/../../lib/fpdf/fpdf.php';
    if (file_exists($fpdfPath)) {
        require_once $fpdfPath;
        $fpdfLoaded = class_exists('FPDF');
    }
}
if (!$fpdfLoaded) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'PDF library missing. Install via Composer (composer require setasign/fpdf) or place fpdf.php + font/ at lib/fpdf/.']);
    exit;
}

$pdo = Database::connection();
$case_status = isset($_GET['status']) ? trim($_GET['status']) : '';

$where = [];
$params = [];
if ($case_status !== '' && in_array($case_status, ['open','closed','under_investigation'], true)) {
    $where[] = 'c.status = ?';
    $params[] = $case_status;
}

$sql = 'SELECT s.full_name, s.national_id, c.case_number, c.title, c.status
        FROM suspect_case_link scl
        JOIN suspects s ON s.id = scl.suspect_id
        JOIN cases c ON c.id = scl.case_id';
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY c.id DESC, s.full_name ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$pdf = new FPDF('P','mm','A4');
$pdf->SetTitle('Suspect Cases Report');
$pdf->AddPage();

// Add Somalia Police logo if available (centered above header)
$logoCandidates = [
    __DIR__ . '/../../public/images/police_logo.png',
    __DIR__ . '/../../public/images/police_logo.jpg',
    __DIR__ . '/../../public/images/police_logo.jpeg',
    __DIR__ . '/../../public/images/somali_police_logo.png',
    __DIR__ . '/../../public/images/somali_police_logo.jpg',
    // fallback if image was placed under public/css/images
    __DIR__ . '/../../public/css/images/police_logo.png',
    __DIR__ . '/../../public/css/images/police_logo.jpg',
    __DIR__ . '/../../public/css/images/police_logo.jpeg',
    __DIR__ . '/../../public/css/images/somali_police_logo.png',
    __DIR__ . '/../../public/css/images/somali_police_logo.jpg',
];
$logoPath = null;
foreach ($logoCandidates as $p) { if (file_exists($p)) { $logoPath = $p; break; } }
if ($logoPath) {
    $pageWidth = $pdf->GetPageWidth();
    $topMargin = 8; // very top
    $logoHeight = 24; // lock height to ensure space below
    // Center by width: give width 0 and set height; FPDF centers by x, so compute x after estimating width by aspect is tricky.
    // Use a fixed width and height to avoid overlap.
    $logoWidth = 40;
    $xCentered = ($pageWidth - $logoWidth) / 2;
    $pdf->Image($logoPath, $xCentered, $topMargin, $logoWidth, $logoHeight);
    // Move below logo and add clear spacing
    $yAfterLogo = $topMargin + $logoHeight + 6;
    $pdf->SetY($yAfterLogo);
    // Divider
    $pdf->SetDrawColor(180,180,180);
    $pdf->Line(12, $yAfterLogo, $pageWidth - 12, $yAfterLogo);
    $pdf->Ln(6);
}

$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,7,'CIIDANKA BOLIISKA SOOMAALIYEED',0,1,'C');
$pdf->SetFont('Arial','',11);
$pdf->Cell(0,6,'SOMALI POLICE FORCE',0,1,'C');
$pdf->Ln(2);
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Suspect Cases Report',0,1,'C');
$pdf->SetFont('Arial','',10);
$subtitle = 'Generated: ' . date('Y-m-d H:i');
if ($case_status !== '') { $subtitle .= ' | Status: ' . $case_status; }
$pdf->Cell(0,6,$subtitle,0,1,'C');
$pdf->Ln(6);

// Table header
$pdf->SetFont('Arial','B',11);
$pdf->Cell(28,8,'Case #',1,0,'L');
$pdf->Cell(60,8,'Case Title',1,0,'L');
$pdf->Cell(32,8,'Status',1,0,'L');
$pdf->Cell(50,8,'Suspect',1,0,'L');
$pdf->Cell(20,8,'Nat. ID',1,1,'L');

$pdf->SetFont('Arial','',10);
foreach ($rows as $r) {
    // Wrap long title/suspect using multi-cell-like approach
    $y = $pdf->GetY();
    $x = $pdf->GetX();
    $lineHeight = 6;
    $maxWidthTitle = 60; $maxWidthSuspect = 50;
    $title = $r['title'];
    $suspect = $r['full_name'];

    // Calculate number of lines for title and suspect
    $titleLines = $pdf->GetStringWidth($title) > $maxWidthTitle ? ceil($pdf->GetStringWidth($title)/$maxWidthTitle) : 1;
    $suspectLines = $pdf->GetStringWidth($suspect) > $maxWidthSuspect ? ceil($pdf->GetStringWidth($suspect)/$maxWidthSuspect) : 1;
    $rowLines = max(1, $titleLines, $suspectLines);
    $rowHeight = $rowLines * $lineHeight;

    // Page break check
    if ($pdf->GetY() + $rowHeight > 280) {
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',11);
        $pdf->Cell(28,8,'Case #',1,0,'L');
        $pdf->Cell(60,8,'Case Title',1,0,'L');
        $pdf->Cell(32,8,'Status',1,0,'L');
        $pdf->Cell(50,8,'Suspect',1,0,'L');
        $pdf->Cell(20,8,'Nat. ID',1,1,'L');
        $pdf->SetFont('Arial','',10);
    }

    $pdf->Cell(28,$rowHeight,$r['case_number'],1,0,'L');
    $x = $pdf->GetX(); $y = $pdf->GetY();
    $pdf->MultiCell(60,$lineHeight,$title,1);
    $pdf->SetXY($x+60,$y);
    $pdf->Cell(32,$rowHeight,$r['status'],1,0,'L');
    $x2 = $pdf->GetX(); $y2 = $pdf->GetY();
    $pdf->MultiCell(50,$lineHeight,$suspect,1);
    $pdf->SetXY($x2+50,$y2);
    $pdf->Cell(20,$rowHeight,($r['national_id'] ?? ''),1,1,'L');
}

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="suspect_cases.pdf"');
$pdf->Output('I','suspect_cases.pdf');
exit;


