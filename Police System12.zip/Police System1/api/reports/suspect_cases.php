<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';

$pdo = Database::connection();
$case_status = isset($_GET['status']) ? trim($_GET['status']) : '';
$suspect_id = isset($_GET['suspect_id']) ? (int)$_GET['suspect_id'] : 0;
$case_id = isset($_GET['case_id']) ? (int)$_GET['case_id'] : 0;

$where = [];
$params = [];
if ($case_status !== '' && in_array($case_status, ['open','closed','under_investigation'], true)) {
    $where[] = 'c.status = ?';
    $params[] = $case_status;
}
if ($suspect_id > 0) {
    $where[] = 's.id = ?';
    $params[] = $suspect_id;
}
if ($case_id > 0) {
    $where[] = 'c.id = ?';
    $params[] = $case_id;
}

$sql = 'SELECT s.id as suspect_id, s.full_name, s.national_id, c.id as case_id, c.case_number, c.title, c.status
        FROM suspect_case_link scl
        JOIN suspects s ON s.id = scl.suspect_id
        JOIN cases c ON c.id = scl.case_id';
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY c.id DESC, s.full_name ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

json_response(['data' => $rows]);


