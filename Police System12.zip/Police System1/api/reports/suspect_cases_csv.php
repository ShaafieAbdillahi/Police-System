<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_once __DIR__ . '/../../db/Database.php';

$status = $_GET['status'] ?? '';
log_activity('export_csv', 'report', null, ['type'=>'suspect_cases','status'=>$status]);

$pdo = Database::connection();
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="suspect_cases.csv"');
$out = fopen('php://output', 'w');
fputcsv($out, ['Case #','Case Title','Status','Suspect','National ID']);

$sql = 'SELECT c.case_number, c.title, c.status, s.full_name, s.national_id
        FROM cases c
        LEFT JOIN suspect_case_link l ON l.case_id = c.id
        LEFT JOIN suspects s ON s.id = l.suspect_id';
$params = [];
if ($status !== '') { $sql .= ' WHERE c.status = ?'; $params[] = $status; }
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
while ($row = $stmt->fetch(PDO::FETCH_NUM)) { fputcsv($out, $row); }
fclose($out);
exit;


