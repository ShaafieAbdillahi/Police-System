<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';

$case_id = (int)($_GET['case_id'] ?? 0);
if ($case_id <= 0) json_response(['error' => 'Invalid case_id'], 422);

$pdo = Database::connection();
$stmt = $pdo->prepare('SELECT id, event_type, description, created_at FROM case_events WHERE case_id = ? ORDER BY id DESC');
$stmt->execute([$case_id]);
json_response(['data' => $stmt->fetchAll()]);


