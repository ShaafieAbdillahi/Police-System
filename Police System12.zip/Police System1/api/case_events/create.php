<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$case_id = (int)($input['case_id'] ?? 0);
$event_type = trim($input['event_type'] ?? '');
$description = trim($input['description'] ?? '');
if ($case_id <= 0 || $event_type === '') json_response(['error' => 'case_id and event_type required'], 422);

$pdo = Database::connection();
$stmt = $pdo->prepare('INSERT INTO case_events (case_id, event_type, description, created_by) VALUES (?, ?, ?, ?)');
$stmt->execute([$case_id, $event_type, $description !== '' ? $description : null, (int)($_SESSION['user_id'] ?? null)]);
json_response(['message' => 'Event logged', 'id' => (int)$pdo->lastInsertId()]);


