<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

$name = trim($input['name'] ?? '');
$username = trim($input['username'] ?? '');
$email = trim($input['email'] ?? '');
$password = (string)($input['password'] ?? '');
$role = trim($input['role'] ?? 'officer');

if ($name === '' || $username === '' || $email === '' || $password === '') {
    json_response(['error' => 'Name, username, email, and password are required'], 422);
}
if (!in_array($role, ['admin','officer','investigator'], true)) {
    json_response(['error' => 'Invalid role'], 422);
}

$pdo = Database::connection();
try {
    $stmt = $pdo->prepare('INSERT INTO users (name, username, email, password, role) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$name, $username, $email, password_hash($password, PASSWORD_BCRYPT), $role]);
} catch (PDOException $e) {
    if ($e->errorInfo[1] === 1062) {
        $msg = 'Duplicate value';
        if (strpos($e->getMessage(), 'username') !== false) $msg = 'Username already exists';
        elseif (strpos($e->getMessage(), 'email') !== false) $msg = 'Email already exists';
        json_response(['error' => $msg], 409);
    }
    throw $e;
}

json_response(['message' => 'User created']);


