<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

$id = (int)($_GET['id'] ?? ($_POST['id'] ?? 0));
if ($id <= 0) json_response(['error' => 'Invalid id'], 422);

$pdo = Database::connection();

// Prevent deleting the last admin
$stmt = $pdo->prepare('SELECT role FROM users WHERE id=?');
$stmt->execute([$id]);
$role = $stmt->fetchColumn();
if ($role === false) json_response(['error' => 'User not found'], 404);
if ($role === 'admin') {
    $count = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
    if ($count <= 1) json_response(['error' => 'Cannot delete the last admin'], 409);
}

// Optionally prevent self-delete to avoid lockouts
if (!empty($_SESSION['user_id']) && (int)$_SESSION['user_id'] === $id) {
    json_response(['error' => 'Cannot delete your own account while logged in'], 409);
}

$stmt = $pdo->prepare('DELETE FROM users WHERE id=?');
$stmt->execute([$id]);

json_response(['message' => 'User deleted']);


