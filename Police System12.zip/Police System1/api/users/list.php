<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';
require_role(['admin']);

$pdo = Database::connection();
$stmt = $pdo->query('SELECT id, name, username, email, role, created_at FROM users ORDER BY id DESC');
json_response(['data' => $stmt->fetchAll()]);


