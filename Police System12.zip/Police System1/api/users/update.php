<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$id = (int)($input['id'] ?? 0);
$name = trim($input['name'] ?? '');
$username = trim($input['username'] ?? '');
$email = trim($input['email'] ?? '');
$role = trim($input['role'] ?? '');
$password = (string)($input['password'] ?? '');

if ($id <= 0 || $name === '' || $username === '' || $email === '' || $role === '') {
    json_response(['error' => 'Missing required fields'], 422);
}
if (!in_array($role, ['admin','officer','investigator'], true)) {
    json_response(['error' => 'Invalid role'], 422);
}

$pdo = Database::connection();

// Prevent removing the last admin
if ($role !== 'admin') {
    $stmt = $pdo->query("SELECT COUNT(*) AS c FROM users WHERE role='admin'");
    $countAdmins = (int)$stmt->fetchColumn();
    $stmt = $pdo->prepare("SELECT role FROM users WHERE id=?");
    $stmt->execute([$id]);
    $currentRole = $stmt->fetchColumn();
    if ($currentRole === 'admin' && $countAdmins <= 1) {
        json_response(['error' => 'Cannot demote the last admin'], 409);
    }
}

try {
    if ($password !== '') {
        $stmt = $pdo->prepare('UPDATE users SET name=?, username=?, email=?, role=?, password=? WHERE id=?');
        $stmt->execute([$name, $username, $email, $role, password_hash($password, PASSWORD_BCRYPT), $id]);
    } else {
        $stmt = $pdo->prepare('UPDATE users SET name=?, username=?, email=?, role=? WHERE id=?');
        $stmt->execute([$name, $username, $email, $role, $id]);
    }
} catch (PDOException $e) {
    if ($e->errorInfo[1] === 1062) {
        $msg = 'Duplicate value';
        if (strpos($e->getMessage(), 'username') !== false) $msg = 'Username already exists';
        elseif (strpos($e->getMessage(), 'email') !== false) $msg = 'Email already exists';
        json_response(['error' => $msg], 409);
    }
    throw $e;
}

json_response(['message' => 'User updated']);

