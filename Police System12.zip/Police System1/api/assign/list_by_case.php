<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../../db/Database.php';

$case_id = (int)($_GET['case_id'] ?? 0);
if ($case_id <= 0) json_response(['error' => 'Invalid case_id'], 422);

$pdo = Database::connection();
$stmt = $pdo->prepare('SELECT scl.id, s.id as suspect_id, s.full_name, s.national_id, scl.created_at FROM suspect_case_link scl JOIN suspects s ON s.id = scl.suspect_id WHERE scl.case_id = ? ORDER BY scl.id DESC');
$stmt->execute([$case_id]);
json_response(['data' => $stmt->fetchAll()]);


