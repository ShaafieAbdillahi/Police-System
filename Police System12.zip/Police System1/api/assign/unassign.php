<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_once __DIR__ . '/../../db/Database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    json_response(['error' => 'Method not allowed'], 405);
}
require_permission('assign.delete');
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) json_response(['error' => 'Invalid id'], 422);

$pdo = Database::connection();
$stmt = $pdo->prepare('DELETE FROM suspect_case_link WHERE id = ?');
$stmt->execute([$id]);
// Log unassignment activity
try {
    log_activity('unassign_suspect', 'assignment', $id);
} catch (Throwable $e) { /* ignore */ }
json_response(['message' => 'Unassigned']);


