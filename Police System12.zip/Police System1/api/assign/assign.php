<?php
require_once __DIR__ . '/../_require_login.php';
require_once __DIR__ . '/../_permissions.php';
require_once __DIR__ . '/../../db/Database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

require_permission('assign.create');

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$case_id = (int)($input['case_id'] ?? 0);
$suspect_id = (int)($input['suspect_id'] ?? 0);
if ($case_id <= 0 || $suspect_id <= 0) json_response(['error' => 'Invalid case_id or suspect_id'], 422);

$pdo = Database::connection();
try {
    $stmt = $pdo->prepare('INSERT INTO suspect_case_link (case_id, suspect_id) VALUES (?, ?)');
    $stmt->execute([$case_id, $suspect_id]);
} catch (PDOException $e) {
    if ($e->errorInfo[1] === 1062) {
        json_response(['error' => 'Suspect already assigned to this case'], 409);
    }
    throw $e;
}

// Log assignment activity
try {
    log_activity('assign_suspect', 'case', $case_id, ['suspect_id' => $suspect_id]);
} catch (Throwable $e) { /* ignore */ }

json_response(['message' => 'Assigned']);


