<?php
// Configuration for database and app

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Update these values for your local setup
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'police_system');
define('DB_USER', 'root');
define('DB_PASS', '');

define('APP_NAME', 'Police Suspect Management System');
define('BASE_URL', '/Police System1');

// Simple JSON response helper
function json_response($data, int $statusCode = 200): void {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Require login for pages
function require_login(): void {
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . '/pages/login.php');
        exit;
    }
}

function require_role(array $roles): void {
    if (empty($_SESSION['role']) || !in_array($_SESSION['role'], $roles, true)) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}


